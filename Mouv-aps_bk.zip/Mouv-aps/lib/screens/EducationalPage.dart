import 'package:flutter/material.dart';

class EducationalPage extends StatefulWidget {
  const EducationalPage({super.key});

  @override
  State<EducationalPage> createState() => _EducationalPageState();
}

class _EducationalPageState extends State<EducationalPage> {
  @override
  Widget build(BuildContext context) {
    return const Scaffold();
  }
}