package com.uphf.mouv_aps

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
